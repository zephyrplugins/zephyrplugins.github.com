from org.python.tests import Invisible
Invisible.protectedStaticField
Invisible().protectedField
Invisible.packageField
